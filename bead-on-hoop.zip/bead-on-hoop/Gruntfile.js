// Copyright 2023, University of Colorado Boulder

/* eslint-env node */

// use chipper's gruntfile
module.exports = require( '../chipper/js/grunt/Gruntfile.js' );
